#ifndef NUMLINE_H
#define NUMLINE_H

void write_log( char * line );
int count_digits( int );

#endif
